<template>
  <div class="hello" >
    <div class="foot-btn">
      <div @click="openCl">
        <div class="btn">&nbsp新&nbsp材&nbsp料&nbsp</div>
        <div>了解更多</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  methods:{
    handleSelect(){

    },
    openCl(){
      this.$router.push({path:`/clx_1`})
      this.$emit('swTab','xcl')
    }
  }
}
</script>

<style scoped>
.foot-btn{
  position: fixed;
  width: 100%;
  bottom: 5rem;
  text-align: center;
  color: #18abd4;
}
.foot-btn .btn{
    display: inline;
    border:3px solid #18abd4;
    padding: 0 1.25rem;
}
.head{
  height:3.75rem;
  background-color:#005bac;
  text-align: center;
  padding: 0.625rem
}
.hello{
	position:absolute;
	top:5rem;
	bottom:0;
	left:0;
	right:0;
  background:url(../../static/cl_1.jpg) center 0 no-repeat;
  background-size: cover;
}
</style>
